// const API_URL = "https://ssknf82q-8000.inc1.devtunnels.ms/api/f1";

const API_URL = "https://g5kqw2tn-3000.inc1.devtunnels.ms/api";

export default API_URL;